<?php
namespace App\Ventas\Controllers;

use App\Http\Controllers\Controller;
use App\Ventas\Models\Item;
use App\Ventas\Models\Empresa;
use App\Ventas\Models\MedioPago;


class VentaController extends Controller
{
    public function index()
    {
        return view('ventas.index');
    }

    public function store()
    {
        // lógica futura
    }

   public function vistaTaquilla()
{
    $datos = Item::taquillaSeparada();

    // Añadir empresas y medios de pago activos
    $datos['empresas'] = Empresa::activas()->get();
    $datos['mediosPago'] = MedioPago::activos()->get();

    return view('ventas.taquilla.index', $datos);
}

   public function vistaCochera()
    {
        $items = Item::where('tipo', 'cochera')->get(); // o como estés filtrando tus ítems

        return view('ventas.cochera.index', [
            'items' => $items,
            'empresas' => Empresa::activas()->get(),
            'mediosPago' => MedioPago::activos()->get(),
        ]);
    }

}

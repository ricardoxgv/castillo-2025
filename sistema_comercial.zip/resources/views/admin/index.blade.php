
<h2>Módulo Admin</h2>
<p>Bienvenido, {{ Auth::user()->name }} ({{ Auth::user()->tipo }})</p>

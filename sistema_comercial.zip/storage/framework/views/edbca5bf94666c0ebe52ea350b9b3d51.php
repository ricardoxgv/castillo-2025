
<h2>Módulo Admin</h2>
<p>Bienvenido, <?php echo e(Auth::user()->name); ?> (<?php echo e(Auth::user()->tipo); ?>)</p>
<?php /**PATH C:\xampp\htdocs\sistema_comercial\resources\views/admin/index.blade.php ENDPATH**/ ?>
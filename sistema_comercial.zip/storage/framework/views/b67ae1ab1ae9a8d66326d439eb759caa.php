

<?php $__env->startSection('content'); ?>
<div style="display: flex; justify-content: space-between; gap: 20px;">
    <!-- Contenido de ítems (entradas y servicios) -->
    <div style="width: 100%;">

        <h2>Venta - Taquilla</h2>

        <h3>Entradas</h3>
        <?php $__empty_1 = true; $__currentLoopData = $entrada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <form method="POST" action="<?php echo e(route('carrito.agregar', $item->id)); ?>" style="margin-bottom: 10px;">
                <?php echo csrf_field(); ?>
                <div style="border: 1px solid #ccc; padding: 10px;">
                    <strong><?php echo e($item->nombre); ?></strong> – $<?php echo e(number_format($item->costo, 2)); ?>

                    <input type="number" name="cantidad" value="1" min="1" style="width: 60px;" />
                    <button type="submit">Agregar al carrito</button>
                </div>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No hay entradas disponibles.</p>
        <?php endif; ?>

        <h3>Servicios</h3>
        <?php $__empty_1 = true; $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <form method="POST" action="<?php echo e(route('carrito.agregar', $item->id)); ?>" style="margin-bottom: 10px;">
                <?php echo csrf_field(); ?>
                <div style="border: 1px solid #ccc; padding: 10px;">
                    <strong><?php echo e($item->nombre); ?></strong> – $<?php echo e(number_format($item->costo, 2)); ?>

                    <input type="number" name="cantidad" value="1" min="1" style="width: 60px;" />
                    <button type="submit">Agregar al carrito</button>
                </div>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No hay servicios disponibles.</p>
        <?php endif; ?>

    </div>

    <!-- Panel lateral del carrito -->
    <?php echo $__env->make('ventas.partials.carrito', [
    'empresas' => $empresas,
    'mediosPago' => $mediosPago
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema_comercial\resources\views/ventas/taquilla/index.blade.php ENDPATH**/ ?>
 

<?php $__env->startSection('content'); ?>
    <h2>Registrar nuevo ítem</h2>

    
    <?php if(session('success')): ?>
        <div style="color: green;"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('items.store')); ?>">
        <?php echo csrf_field(); ?>

        <label for="nombre">Nombre del ítem:</label><br>
        <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>" required><br><br>

        <label for="tipo">Tipo:</label><br>
        <select name="tipo" required>
            <option value="">-- Seleccione --</option>
            <option value="entrada" <?php echo e(old('tipo') == 'entrada' ? 'selected' : ''); ?>>Entrada</option>
            <option value="servicio" <?php echo e(old('tipo') == 'servicio' ? 'selected' : ''); ?>>Servicio</option>
            <option value="cochera" <?php echo e(old('tipo') == 'cochera' ? 'selected' : ''); ?>>Cochera</option>
        </select><br><br>
        <label for="categoria">Categoría:</label><br>
            <select name="categoria" required>
                <option value="general" <?php echo e(old('categoria') == 'general' ? 'selected' : ''); ?>>General</option>
                <option value="exonerado" <?php echo e(old('categoria') == 'exonerado' ? 'selected' : ''); ?>>Exonerado (Marina, CONADIS...)</option>
                <option value="invitado" <?php echo e(old('categoria') == 'invitado' ? 'selected' : ''); ?>>Invitado (Cortesía, Marketing...)</option>
            </select><br><br>

        <label for="costo">Costo:</label><br>
        <input type="number" name="costo" step="0.01" value="<?php echo e(old('costo')); ?>" required><br><br>

        <button type="submit">Guardar ítem</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema_comercial\resources\views/ventas/items/create.blade.php ENDPATH**/ ?>
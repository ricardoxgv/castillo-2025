<?php
    $carrito = session('carrito.items', []);
    $descuento_global = session('carrito.descuento_global', 0);
    $monto_total = 0;
    $hay_descuento_individual = false;
?>

<div style="position: fixed; top: 80px; right: 20px; width: 450px; border-left: 2px solid #ccc; padding: 15px; background-color: #f9f9f9;">
    <h3>🍎 Carrito</h3>

    <?php if(empty($carrito)): ?>
        <p>No hay ítems en el carrito.</p>
    <?php else: ?>
        <table style="width: 100%; font-size: 14px; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Cant.</th>
                    <th>Precio UND</th>
                    <th>Submonto</th>
                    <th>Descuento</th>
                    <th>Total</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $descuento = $item['descuento'] ?? 0;
                        $precio_unitario = $item['precio_unitario'];
                        $submonto = $precio_unitario * $item['cantidad'];
                        $monto_final = $submonto - $descuento;
                        $monto_total += $monto_final;
                        if ($descuento > 0) $hay_descuento_individual = true;
                    ?>
                    <tr>
                        <td><?php echo e($item['nombre']); ?></td>
                        <td style="text-align: center;"><?php echo e($item['cantidad']); ?></td>
                        <td style="text-align: right;">S/ <?php echo e(number_format($precio_unitario, 2)); ?></td>
                        <td style="text-align: right;">S/ <?php echo e(number_format($submonto, 2)); ?></td>
                        <td style="text-align: center;">
                            <?php if($descuento > 0): ?>
                                <?php if(str_contains($item['descuento_text'] ?? '', '%')): ?>
                                    -<?php echo e($item['descuento_text']); ?> (S/ <?php echo e(number_format($descuento, 2)); ?>)
                                <?php else: ?>
                                    - S/ <?php echo e(number_format($descuento, 2)); ?>

                                <?php endif; ?>
                            <?php else: ?>
                                <input type="checkbox" class="descuento-toggle" data-id="<?php echo e($key); ?>" <?php if($descuento_global > 0): ?> disabled <?php endif; ?>>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right;">S/ <?php echo e(number_format($monto_final, 2)); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('carrito.eliminar', $key)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit">❌</button>
                            </form>
                        </td>
                    </tr>
                    <tr id="descuento-form-<?php echo e($key); ?>" class="descuento-form-row" style="display: none;">
                        <td colspan="7">
                            <form method="POST" action="<?php echo e(route('carrito.descuento', $key)); ?>">
                                <?php echo csrf_field(); ?>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <span>Submonto: <strong>S/ <?php echo e(number_format($submonto, 2)); ?></strong></span>
                                    <label>Descuento:</label>
                                    <input type="text" name="descuento" placeholder="10 o 10%" style="width: 80px;" required>
                                    <button type="submit">✔ OK</button>
                                    <button type="button" class="cancelar-descuento" data-id="<?php echo e($key); ?>">✖ Cancelar</button>
                                </div>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php
            $descuento_global_text = session('carrito.descuento_global_text', '');
            $descuento_global_monto = 0;
            if (str_contains($descuento_global_text, '%')) {
                $porcentaje = floatval(str_replace('%', '', $descuento_global_text)) / 100;
                $descuento_global_monto = $monto_total * $porcentaje;
            } else {
                $descuento_global_monto = floatval($descuento_global);
            }
            $total_final = $monto_total - $descuento_global_monto;
            $subtotal = $total_final / 1.18;
            $igv = $total_final - $subtotal;
        ?>

        <div style="margin-top: 10px; text-align: right;">
            <p><strong>Subtotal:</strong> S/ <?php echo e(number_format($subtotal, 2)); ?></p>
            <p><strong>IGV (18%):</strong> S/ <?php echo e(number_format($igv, 2)); ?></p>
            <p><strong>Total:</strong> S/ <?php echo e(number_format($monto_total, 2)); ?></p>

            <?php if($descuento_global_monto > 0): ?>
                <p><strong>💸 Descuento Global:</strong>
                    -<?php echo e($descuento_global_text ?: 'S/ ' . number_format($descuento_global_monto, 2)); ?>

                </p>
                <p><strong>💰 Precio Promocional:</strong> S/ <?php echo e(number_format($total_final, 2)); ?></p>
            <?php endif; ?>

            <?php if($hay_descuento_individual): ?>
                <p style="color: red;"><strong>⚠ Ya hay descuentos individuales. El descuento global no se puede aplicar.</strong></p>
            <?php endif; ?>
            <?php if($descuento_global_monto > 0): ?>
                <p style="color: red;"><strong>⚠ Ya hay un descuento global aplicado.</strong></p>
            <?php endif; ?>
        </div>

        <form method="POST" action="<?php echo e(route('carrito.descuento.global')); ?>" style="margin-top: 10px; text-align: right;">
            <?php echo csrf_field(); ?>
            <label for="descuento_global"><strong>Aplicar descuento global:</strong></label>
            <input type="text" name="descuento" id="descuento_global" placeholder="10 o 10%" style="width: 80px;"
                   <?php if($descuento_global_monto > 0 || $hay_descuento_individual): ?> disabled <?php endif; ?> required>
            <button type="submit" <?php if($descuento_global_monto > 0 || $hay_descuento_individual): ?> disabled <?php endif; ?>>💸 Aplicar</button>
        </form>

        <?php if($descuento_global_monto > 0): ?>
            <form method="POST" action="<?php echo e(route('carrito.descuento.global')); ?>" style="margin-top: 5px; text-align: right;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="descuento" value="0">
                <button type="submit" style="background-color: #f99;">❌ Limpiar Descuento Global</button>
            </form>
        <?php endif; ?>

                <!-- Medio de Pago -->
        <form method="POST" action="<?php echo e(route('carrito.seleccionar.medio_pago')); ?>" style="margin-top: 15px; text-align: right;">
            <?php echo csrf_field(); ?>
            <label for="medio_pago_id"><strong>Medio de Pago:</strong></label>
            <select name="medio_pago_id" id="medio_pago_id" required>
                <option value="">-- Seleccionar --</option>
                <?php $__currentLoopData = $mediosPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($medio->id); ?>" <?php echo e(session('carrito.medio_pago_id') == $medio->id ? 'selected' : ''); ?>>
                        <?php echo e($medio->nombre); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label style="margin-left: 10px;">
                <input type="checkbox" name="fijar_medio" value="1"
                    <?php echo e(session()->has('carrito.medio_pago_id') ? 'checked' : ''); ?>

                    onchange="this.form.submit()">
                Fijar
            </label>
        </form>

        <!-- Empresa -->
        <form method="POST" action="<?php echo e(route('carrito.seleccionar.empresa')); ?>" style="margin-top: 10px; text-align: right;">
            <?php echo csrf_field(); ?>
            <label for="empresa_id"><strong>Empresa:</strong></label>
            <select name="empresa_id" id="empresa_id" required>
                <option value="">-- Seleccionar --</option>
                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($empresa->id); ?>" <?php echo e(session('carrito.empresa_id') == $empresa->id ? 'selected' : ''); ?>>
                        <?php echo e($empresa->nombre); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label style="margin-left: 10px;">
                <input type="checkbox" name="fijar_empresa" value="1"
                    <?php echo e(session()->has('carrito.empresa_id') ? 'checked' : ''); ?>

                    onchange="this.form.submit()">
                Fijar
            </label>
        </form>

    <?php endif; ?>
</div>

<script>
    document.querySelectorAll('.descuento-toggle').forEach(chk => {
        chk.addEventListener('change', function () {
            const id = this.dataset.id;
            document.getElementById('descuento-form-' + id).style.display = this.checked ? 'table-row' : 'none';
        });
    });

    document.querySelectorAll('.cancelar-descuento').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = this.dataset.id;
            document.getElementById('descuento-form-' + id).style.display = 'none';
            document.querySelector(`.descuento-toggle[data-id="${id}"]`).checked = false;
        });
    });

    
</script>

<script>
    function controlarCheckboxVisualmente(selector, selectId) {
        const checkbox = document.querySelector(selector);
        const select = document.getElementById(selectId);

        if (!checkbox || !select) return;

        // Inicializar según estado actual del checkbox
        select.readOnly = checkbox.checked;
        select.style.backgroundColor = checkbox.checked ? '#eee' : '';
        select.style.pointerEvents = checkbox.checked ? 'none' : 'auto';

        checkbox.addEventListener('change', function () {
            if (this.checked) {
                select.readOnly = true;
                select.style.backgroundColor = '#eee';
                select.style.pointerEvents = 'none';
            } else {
                select.readOnly = false;
                select.style.backgroundColor = '';
                select.style.pointerEvents = 'auto';
            }
        });
    }

    // Llamar para cada combo
    controlarCheckboxVisualmente('input[name="fijar_medio"]', 'medio_pago_id');
    controlarCheckboxVisualmente('input[name="fijar_empresa"]', 'empresa_id');
</script>
<?php /**PATH C:\xampp\htdocs\sistema_comercial\resources\views/ventas/partials/carrito.blade.php ENDPATH**/ ?>
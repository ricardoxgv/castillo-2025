<?php

namespace App\Facturacion\Controllers;

use App\Http\Controllers\Controller;

class FacturaController extends Controller
{
    public function index()
    {
        return view('facturacion.index');
    }

    public function store()
    {
        // lógica futura
    }
}

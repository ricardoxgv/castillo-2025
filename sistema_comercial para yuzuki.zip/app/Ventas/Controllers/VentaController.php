<?php
namespace App\Ventas\Controllers;

use App\Http\Controllers\Controller;
use App\Ventas\Models\Item;


class VentaController extends Controller
{
    public function index()
    {
        return view('ventas.index');
    }

    public function store()
    {
        // lógica futura
    }

    public function vistaTaquilla()
    {
        $datos = Item::taquillaSeparada();
        return view('ventas.taquilla.index', $datos);
    }

    public function vistaCochera()
    {
        $items = Item::cochera();
        return view('ventas.cochera.index', compact('items'));
    }

}

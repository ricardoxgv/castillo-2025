
<h2>Módulo de Facturacion</h2>
<p>Bienvenido, {{ Auth::user()->name }} ({{ Auth::user()->tipo }})</p>

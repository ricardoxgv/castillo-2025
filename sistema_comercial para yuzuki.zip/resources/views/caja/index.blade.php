
<h2>Módulo de Caja</h2>
<p>Bienvenido, {{ Auth::user()->name }} ({{ Auth::user()->tipo }})</p>

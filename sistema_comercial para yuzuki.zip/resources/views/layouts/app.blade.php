<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Sistema Comercial')</title>
</head>
<body>
    <div class="container">
        @yield('content')
    </div>
</body>
</html>

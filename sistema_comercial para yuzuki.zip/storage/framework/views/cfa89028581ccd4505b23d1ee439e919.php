<!-- resources/views/ventas/partials/carrito.blade.php -->
<div style="position: fixed; top: 80px; right: 20px; width: 450px; border-left: 2px solid #ccc; padding: 15px; background-color: #f9f9f9;">
    <h3>🛒 Carrito</h3>

    <?php
        $carrito = session('carrito.items', []);
        $monto_total = 0;
    ?>

    <?php if(empty($carrito)): ?>
        <p>No hay ítems en el carrito.</p>
    <?php else: ?>
        <table style="width: 100%; font-size: 14px; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Cant.</th>
                    <th>Precio UND</th>
                    <th>Sub monto</th>
                    <th>Descuento</th>
                    <th>Monto</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $descuento = $item['descuento'] ?? 0;
                        $precio_unitario = $item['precio_unitario'];
                        $submonto = $precio_unitario * $item['cantidad'];
                        $monto_final = $submonto - $descuento;
                        $monto_total += $monto_final;
                    ?>
                    <tr>
                        <td><?php echo e($item['nombre']); ?></td>
                        <td style="text-align: center;"><?php echo e($item['cantidad']); ?></td>
                        <td style="text-align: right;">S/ <?php echo e(number_format($precio_unitario, 2)); ?></td>
                        <td style="text-align: right;">S/ <?php echo e(number_format($submonto, 2)); ?></td>
                        <td style="text-align: center;">
                            <?php if($descuento > 0): ?>
                                <?php if(str_contains($item['descuento_text'] ?? '', '%')): ?>
                                    -<?php echo e($item['descuento_text']); ?> (S/ <?php echo e(number_format($descuento, 2)); ?>)
                                <?php else: ?>
                                    - S/ <?php echo e(number_format($descuento, 2)); ?>

                                <?php endif; ?>
                            <?php else: ?>
                                <input type="checkbox" class="descuento-toggle" data-id="<?php echo e($key); ?>">
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right;">S/ <?php echo e(number_format($monto_final, 2)); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('carrito.eliminar', $key)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit">❌</button>
                            </form>
                        </td>
                    </tr>

                    <!-- Formulario para aplicar descuento -->
                    <tr id="descuento-form-<?php echo e($key); ?>" class="descuento-form-row" style="display: none;">
                        <td colspan="7">
                            <form method="POST" action="<?php echo e(route('carrito.descuento', $key)); ?>">
                                <?php echo csrf_field(); ?>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <span>Submonto: <strong>S/ <?php echo e(number_format($submonto, 2)); ?></strong></span>
                                    <label>Descuento:</label>
                                    <input type="text" name="descuento" placeholder="10 o 10%" style="width: 80px;" required>
                                    <button type="submit">✔ OK</button>
                                    <button type="button" class="cancelar-descuento" data-id="<?php echo e($key); ?>">✖ Cancelar</button>
                                </div>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php
            $subtotal = $monto_total / 1.18;
            $igv = $monto_total - $subtotal;
        ?>

        <div style="margin-top: 10px; text-align: right;">
            <p><strong>Subtotal:</strong> S/ <?php echo e(number_format($subtotal, 2)); ?></p>
            <p><strong>IGV (18%):</strong> S/ <?php echo e(number_format($igv, 2)); ?></p>
            <p><strong>Total:</strong> S/ <?php echo e(number_format($monto_total, 2)); ?></p>
        </div>
        <form method="POST" action="<?php echo e(route('carrito.descuento.global')); ?>" style="margin-top: 10px; text-align: right;">
        <?php echo csrf_field(); ?>
        <label for="descuento_global"><strong>Aplicar descuento global:</strong></label>
        <input type="text" name="descuento" id="descuento_global" placeholder="10 o 10%" style="width: 80px;" required>
        <button type="submit">💸 Aplicar</button>
        </form>

        <form method="POST" action="<?php echo e(route('carrito.limpiar')); ?>" style="margin-top: 10px; text-align: right;">
            <?php echo csrf_field(); ?>
            <button type="submit">🧹 Limpiar Carrito</button>
        </form>
    <?php endif; ?>
</div>

<script>
    // Mostrar u ocultar la fila de descuento
    document.querySelectorAll('.descuento-toggle').forEach(checkbox => {
        checkbox.addEventListener('change', function () {
            const id = this.dataset.id;
            const row = document.getElementById('descuento-form-' + id);
            row.style.display = this.checked ? 'table-row' : 'none';
        });
    });

    document.querySelectorAll('.cancelar-descuento').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = this.dataset.id;
            const row = document.getElementById('descuento-form-' + id);
            row.style.display = 'none';
            document.querySelector(`.descuento-toggle[data-id="${id}"]`).checked = false;
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\sistema_comercial\resources\views/ventas/partials/carrito.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <h2>Apertura de Ventas</h2>

    <?php if(session('error')): ?>
        <div style="color: red"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('apertura.crear')); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de aperturar esta opción?')">
        <?php echo csrf_field(); ?>
        <button type="submit" name="tipo" value="taquilla">Aperturar Taquilla</button>
        <button type="submit" name="tipo" value="cochera">Aperturar Cochera</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema_comercial\resources\views/ventas/aperturas/seleccionar.blade.php ENDPATH**/ ?>
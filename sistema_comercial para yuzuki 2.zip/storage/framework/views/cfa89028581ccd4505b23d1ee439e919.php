<?php
    $carrito = session('carrito.items', []);
    $descuento_global = session('carrito.descuento_global', 0);
    $monto_total = 0;
    $hay_descuento_individual = false;
?>

<!-- Carrito UI -->
<div style="position: fixed; top: 80px; right: 20px; width: 450px; border-left: 2px solid #ccc; padding: 15px; background-color: #f9f9f9;">
    <h3>🛒 Carrito</h3>

    <?php if(empty($carrito)): ?>
        <p>No hay ítems en el carrito.</p>
    <?php else: ?>
        <table style="width: 100%; font-size: 14px; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Cant.</th>
                    <th>Precio UND</th>
                    <th>Submonto</th>
                    <th>Descuento</th>
                    <th>Total</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $descuento = $item['descuento'] ?? 0;
                        $precio_unitario = $item['precio_unitario'];
                        $submonto = $precio_unitario * $item['cantidad'];
                        $monto_final = $submonto - $descuento;
                        $monto_total += $submonto;
                        if ($descuento > 0) $hay_descuento_individual = true;
                    ?>
                    <tr>
                        <td><?php echo e($item['nombre']); ?></td>
                        <td style="text-align: center;"><?php echo e($item['cantidad']); ?></td>
                        <td style="text-align: right;">S/ <?php echo e(number_format($precio_unitario, 2)); ?></td>
                        <td style="text-align: right;">S/ <?php echo e(number_format($submonto, 2)); ?></td>
                        <td style="text-align: center;">
                            <?php if($descuento > 0): ?>
                                <?php if(str_contains($item['descuento_text'] ?? '', '%')): ?>
                                    -<?php echo e($item['descuento_text']); ?> (S/ <?php echo e(number_format($descuento, 2)); ?>)
                                <?php else: ?>
                                    - S/ <?php echo e(number_format($descuento, 2)); ?>

                                <?php endif; ?>
                            <?php else: ?>
                                <input type="checkbox" class="descuento-toggle" data-id="<?php echo e($key); ?>" <?php if($descuento_global > 0): ?> disabled <?php endif; ?>>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right;">S/ <?php echo e(number_format($monto_final, 2)); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('carrito.eliminar', $key)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit">❌</button>
                            </form>
                        </td>
                    </tr>

                    <!-- Descuento formulario -->
                    <tr id="descuento-form-<?php echo e($key); ?>" class="descuento-form-row" style="display: none;">
                        <td colspan="7">
                            <form method="POST" action="<?php echo e(route('carrito.descuento', $key)); ?>">
                                <?php echo csrf_field(); ?>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <label>Descuento:</label>
                                    <input type="text" name="descuento" placeholder="10 o 10%" required style="width: 80px;">
                                    <button type="submit">✔ Aplicar</button>
                                    <button type="button" class="cancelar-descuento" data-id="<?php echo e($key); ?>">✖ Cancelar</button>
                                </div>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php
            $subtotal = $monto_total / 1.18;
            $igv = $monto_total - $subtotal;
            $precio_promocional = $monto_total - $descuento_global;
        ?>

        <div style="margin-top: 10px; text-align: right;">
            <p><strong>Subtotal:</strong> S/ <?php echo e(number_format($subtotal, 2)); ?></p>
            <p><strong>IGV (18%):</strong> S/ <?php echo e(number_format($igv, 2)); ?></p>
            <p><strong>Total:</strong> S/ <?php echo e(number_format($monto_total, 2)); ?></p>

            <?php if($descuento_global > 0): ?>
                <?php
            $descuento_texto = session('carrito.descuento_global_text', '');
        ?>

        <p><strong>💸 Descuento Global:</strong> 
            <?php if($descuento_texto): ?>
                -<?php echo e($descuento_texto); ?> (S/ <?php echo e(number_format($descuento_global, 2)); ?>)
            <?php else: ?>
                -S/ <?php echo e(number_format($descuento_global, 2)); ?>

            <?php endif; ?>
        </p>
                <p><strong>💰 Precio Promocional:</strong> S/ <?php echo e(number_format($precio_promocional, 2)); ?></p>
            <?php endif; ?>

            <?php if($hay_descuento_individual): ?>
                <p style="color: red;"><strong>⚠ Ya hay descuentos individuales. El descuento global no se puede aplicar.</strong></p>
            <?php endif; ?>

            <?php if($descuento_global > 0): ?>
                <p style="color: red;"><strong>⚠ Ya hay un descuento global aplicado.</strong></p>
            <?php endif; ?>
        </div>

        <form method="POST" action="<?php echo e(route('carrito.descuento.global')); ?>" style="margin-top: 10px; text-align: right;">
            <?php echo csrf_field(); ?>
            <label for="descuento_global">Aplicar descuento global:</label>
            <input type="text" name="descuento" id="descuento_global" placeholder="10 o 10%" style="width: 80px;" 
                   <?php if($hay_descuento_individual || $descuento_global > 0): ?> disabled <?php endif; ?> required>
            <button type="submit" <?php if($hay_descuento_individual || $descuento_global > 0): ?> disabled <?php endif; ?>>Aplicar</button>
        </form>

        <?php if($descuento_global > 0): ?>
            <form method="POST" action="<?php echo e(route('carrito.descuento.global')); ?>" style="margin-top: 5px; text-align: right;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="descuento" value="0">
                <button type="submit" style="background-color: #f99;">❌ Limpiar Descuento Global</button>
            </form>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('carrito.limpiar')); ?>" style="margin-top: 10px; text-align: right;">
            <?php echo csrf_field(); ?>
            <button type="submit">🧹 Limpiar Carrito</button>
        </form>
    <?php endif; ?>
</div>

<script>
    document.querySelectorAll('.descuento-toggle').forEach(chk => {
        chk.addEventListener('change', function () {
            const id = this.dataset.id;
            document.getElementById('descuento-form-' + id).style.display = this.checked ? 'table-row' : 'none';
        });
    });

    document.querySelectorAll('.cancelar-descuento').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = this.dataset.id;
            document.getElementById('descuento-form-' + id).style.display = 'none';
            document.querySelector(`.descuento-toggle[data-id="${id}"]`).checked = false;
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\sistema_comercial\resources\views/ventas/partials/carrito.blade.php ENDPATH**/ ?>
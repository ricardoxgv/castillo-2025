

<?php $__env->startSection('content'); ?>
    <h1>Listado de Ítems</h1>

    <?php if(session('success')): ?>
        <div style="color: green"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table border="1" cellpadding="10">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Costo</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->nombre); ?></td>
                    <td>S/. <?php echo e(number_format($item->costo, 2)); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('items.toggle', $item->id)); ?>" onsubmit="return confirmCambio(this, '<?php echo e($item->estado ? 'desactivar' : 'activar'); ?>')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit">
                                <?php echo e($item->estado ? 'Activo' : 'Inactivo'); ?>

                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <script>
        function confirmCambio(form, accion) {
            return confirm('¿Estás seguro que deseas ' + accion + ' este ítem?');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema_comercial\resources\views/ventas/items/index.blade.php ENDPATH**/ ?>
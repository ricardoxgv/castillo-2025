
<h2>Módulo de reportes</h2>
<p>Bienvenido, {{ Auth::user()->name }} ({{ Auth::user()->tipo }})</p>

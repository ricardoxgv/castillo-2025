@php
    $carrito = session('carrito.items', []);
    $descuento_global = session('carrito.descuento_global', 0);
    $monto_total = 0;
    $hay_descuento_individual = false;
@endphp

<!-- Carrito UI -->
<div style="position: fixed; top: 80px; right: 20px; width: 450px; border-left: 2px solid #ccc; padding: 15px; background-color: #f9f9f9;">
    <h3>🛒 Carrito</h3>

    @if (empty($carrito))
        <p>No hay ítems en el carrito.</p>
    @else
        <table style="width: 100%; font-size: 14px; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Cant.</th>
                    <th>Precio UND</th>
                    <th>Submonto</th>
                    <th>Descuento</th>
                    <th>Total</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @foreach ($carrito as $key => $item)
                    @php
                        $descuento = $item['descuento'] ?? 0;
                        $precio_unitario = $item['precio_unitario'];
                        $submonto = $precio_unitario * $item['cantidad'];
                        $monto_final = $submonto - $descuento;
                        $monto_total += $submonto;
                        if ($descuento > 0) $hay_descuento_individual = true;
                    @endphp
                    <tr>
                        <td>{{ $item['nombre'] }}</td>
                        <td style="text-align: center;">{{ $item['cantidad'] }}</td>
                        <td style="text-align: right;">S/ {{ number_format($precio_unitario, 2) }}</td>
                        <td style="text-align: right;">S/ {{ number_format($submonto, 2) }}</td>
                        <td style="text-align: center;">
                            @if ($descuento > 0)
                                @if (str_contains($item['descuento_text'] ?? '', '%'))
                                    -{{ $item['descuento_text'] }} (S/ {{ number_format($descuento, 2) }})
                                @else
                                    - S/ {{ number_format($descuento, 2) }}
                                @endif
                            @else
                                <input type="checkbox" class="descuento-toggle" data-id="{{ $key }}" @if($descuento_global > 0) disabled @endif>
                            @endif
                        </td>
                        <td style="text-align: right;">S/ {{ number_format($monto_final, 2) }}</td>
                        <td>
                            <form method="POST" action="{{ route('carrito.eliminar', $key) }}">
                                @csrf
                                @method('DELETE')
                                <button type="submit">❌</button>
                            </form>
                        </td>
                    </tr>

                    <!-- Descuento formulario -->
                    <tr id="descuento-form-{{ $key }}" class="descuento-form-row" style="display: none;">
                        <td colspan="7">
                            <form method="POST" action="{{ route('carrito.descuento', $key) }}">
                                @csrf
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <label>Descuento:</label>
                                    <input type="text" name="descuento" placeholder="10 o 10%" required style="width: 80px;">
                                    <button type="submit">✔ Aplicar</button>
                                    <button type="button" class="cancelar-descuento" data-id="{{ $key }}">✖ Cancelar</button>
                                </div>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        @php
            $subtotal = $monto_total / 1.18;
            $igv = $monto_total - $subtotal;
            $precio_promocional = $monto_total - $descuento_global;
        @endphp

        <div style="margin-top: 10px; text-align: right;">
            <p><strong>Subtotal:</strong> S/ {{ number_format($subtotal, 2) }}</p>
            <p><strong>IGV (18%):</strong> S/ {{ number_format($igv, 2) }}</p>
            <p><strong>Total:</strong> S/ {{ number_format($monto_total, 2) }}</p>

            @if ($descuento_global > 0)
                @php
            $descuento_texto = session('carrito.descuento_global_text', '');
        @endphp

        <p><strong>💸 Descuento Global:</strong> 
            @if ($descuento_texto)
                -{{ $descuento_texto }} (S/ {{ number_format($descuento_global, 2) }})
            @else
                -S/ {{ number_format($descuento_global, 2) }}
            @endif
        </p>
                <p><strong>💰 Precio Promocional:</strong> S/ {{ number_format($precio_promocional, 2) }}</p>
            @endif

            @if ($hay_descuento_individual)
                <p style="color: red;"><strong>⚠ Ya hay descuentos individuales. El descuento global no se puede aplicar.</strong></p>
            @endif

            @if ($descuento_global > 0)
                <p style="color: red;"><strong>⚠ Ya hay un descuento global aplicado.</strong></p>
            @endif
        </div>

        <form method="POST" action="{{ route('carrito.descuento.global') }}" style="margin-top: 10px; text-align: right;">
            @csrf
            <label for="descuento_global">Aplicar descuento global:</label>
            <input type="text" name="descuento" id="descuento_global" placeholder="10 o 10%" style="width: 80px;" 
                   @if($hay_descuento_individual || $descuento_global > 0) disabled @endif required>
            <button type="submit" @if($hay_descuento_individual || $descuento_global > 0) disabled @endif>Aplicar</button>
        </form>

        @if ($descuento_global > 0)
            <form method="POST" action="{{ route('carrito.descuento.global') }}" style="margin-top: 5px; text-align: right;">
                @csrf
                <input type="hidden" name="descuento" value="0">
                <button type="submit" style="background-color: #f99;">❌ Limpiar Descuento Global</button>
            </form>
        @endif

        <form method="POST" action="{{ route('carrito.limpiar') }}" style="margin-top: 10px; text-align: right;">
            @csrf
            <button type="submit">🧹 Limpiar Carrito</button>
        </form>
    @endif
</div>

<script>
    document.querySelectorAll('.descuento-toggle').forEach(chk => {
        chk.addEventListener('change', function () {
            const id = this.dataset.id;
            document.getElementById('descuento-form-' + id).style.display = this.checked ? 'table-row' : 'none';
        });
    });

    document.querySelectorAll('.cancelar-descuento').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = this.dataset.id;
            document.getElementById('descuento-form-' + id).style.display = 'none';
            document.querySelector(`.descuento-toggle[data-id="${id}"]`).checked = false;
        });
    });
</script>

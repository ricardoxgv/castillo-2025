<?php

namespace App\Ventas\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Ventas\Models\Item;
use App\Ventas\Models\Carrito;

class CarritoController extends Controller
{
    public function agregar(Request $request, $itemId)
    {
        $item = Item::findOrFail($itemId);
        Carrito::agregar($item, $request->input('cantidad', 1));
        return back();
    }

    public function limpiar()
    {
        Carrito::limpiar();
        return back();
    }

    public function eliminar($id)
    {
        \App\Ventas\Models\Carrito::eliminar($id);
        return redirect()->back();
    }

    public function descontar(Request $request, $itemId)
    {
        $valor = $request->input('descuento');
        Carrito::aplicarDescuento($itemId, $valor);
        return back()->with('success', 'Descuento aplicado correctamente.');
    }

    public function aplicarDescuento(Request $request, $itemId)
    {
        Carrito::aplicarDescuento($itemId, $request->input('descuento'));
        return redirect()->back();
    }

    public function aplicarDescuentoGlobal(Request $request)
{
    $valor = $request->input('descuento');
    
    $resultado = Carrito::aplicarDescuentoGlobal($valor);

    if ($resultado == 'error') {
        return back()->with('error', 'Debes eliminar los descuentos individuales antes de aplicar un descuento global.');
    }

    return back()->with('success', 'Descuento global aplicado.');
}

}

<?php

namespace App\Control\Controllers;

use App\Http\Controllers\Controller;

class ControlController extends Controller
{
    public function index()
    {
        return view('control.index');
    }

    public function store()
    {
        // lógica futura
    }
}

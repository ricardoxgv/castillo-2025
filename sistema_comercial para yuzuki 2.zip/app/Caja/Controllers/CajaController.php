<?php

namespace App\Caja\Controllers;

use App\Http\Controllers\Controller;

class CajaController extends Controller
{
    public function index()
    {
        return view('caja.index');
    }

    public function store()
    {
        // lógica futura
    }
}
